<?php
// Adyen PHP API Library v17.4.0
use Adyen\Client;
use Adyen\Environment;
use Adyen\Model\Checkout\Amount;
use Adyen\Model\Checkout\CreateCheckoutSessionRequest;
use Adyen\Service\Checkout\PaymentsApi;

function getCheckoutSession($price)
{
  $client = new Client();
  $client->setXApiKey("AQExhmfxLI7ObRVKw0m/n3Q5qf3Vbp5fDpxrW2ZZ03a/yTQYdSPjEboLodqCZxYNQvb1vRDBXVsNvuR83LVYjEgiTGAH-l5Q6uyEDd09gq9L4y+xXXTx3RpONfYuruGfbLDvmAX0=-7:*sPnwK4ZE(>:;8");
  $client->setEnvironment(Environment::TEST);

  // Create the request object(s)
  $amount = new Amount();
  $amount
    ->setCurrency("PHP")
    ->setValue($price); // get the data from the db 

  $createCheckoutSessionRequest = new CreateCheckoutSessionRequest();
  $createCheckoutSessionRequest
    ->setReference("FURCO")
    ->setAmount($amount)
    ->setMerchantAccount("FurcoAccount723ECOM")
    ->setCountryCode("PH")
    ->setReturnUrl("http://localhost/Latest%20File/sucess.php")
    ->setRecurringProcessingModel('Subscription')
    ->setShopperInteraction('ContAuth')
    ->setStorePaymentMethod(true)
    ->setShopperReference(rand(1, 10000000));



  // Make the API call
  $service = new PaymentsApi($client);
  $response = $service->sessions($createCheckoutSessionRequest);
  // var_dump($response);
  return $response;
}

?>