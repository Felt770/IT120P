  <?php

  function checkout($user_id,$order_date,$payment,$userAddress,$delivery_date,$status,$cartItems,$totalPrice,$active)
  {
  $conn = db_connect();



  $stmt = $conn->prepare("INSERT INTO orders (user_id, order_date, payment_method, shipping_address, order_total, delivery_date, order_status) VALUES (?,?,?,?,?,?,?)");
  $stmt->bind_param("ississs", $user_id, $order_date , $payment, $userAddress, $totalPrice, $delivery_date, $status);
  $stmt->execute();

  foreach ($cartItems as $item) {
      $product_id = $item['product_id'];
      $order_id = $stmt->insert_id;
      $quantity = $item['quantity'];

      $stmt = $conn->prepare("INSERT INTO order_items (product_id, order_id, qty, subtotal) VALUES (?, ?, ?, ?)");
      $stmt->bind_param("iiss", $product_id, $order_id, $quantity, $totalPrice);
      $stmt->execute();
  }
  foreach ($cartItems as $item) {
    $product_id = $item['product_id'];
    $quantity = $item['quantity'];
    $frequency =$item['subscription'];

  $stmt = $conn->prepare("INSERT INTO subscriptions (user_id, product_id, frequency	, start_date, next_delivery, quantity	, active) VALUES (?,?,?,?,?,?,?)");
  $stmt->bind_param("iisssss", $user_id, $product_id , $frequency, $order_date, $totalPrice, $delivery_date, $active);
  $stmt->execute();

  }
  }

  function clearCart($user_id, $conn) {
    $stmt = $conn->prepare("DELETE FROM cart WHERE user_id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    }  

  ?>

