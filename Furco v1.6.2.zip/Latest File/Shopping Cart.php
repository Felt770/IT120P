<?php
include('Adyen/client.php');
include('Php/functions.php');
include('Php/checkout.php');
$conn = db_connect();
$user_id = $_SESSION['user_id'] ?? 0; // Ensure you handle the case where session is not set


// Handling removal and quantity, size, subscription updates
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  if (isset($_POST['remove'])) {
    $cart_id = $_POST['cart_id'];
    // Delete based on cart_id, not product_id
    $stmt = $conn->prepare("DELETE FROM cart WHERE id = ?");
    $stmt->bind_param("i", $cart_id);
    $stmt->execute();
  } elseif (isset($_POST['update'])) {
    $cart_id = $_POST['cart_id'];
    $quantity = $_POST['quantity'];
    $size = $_POST['size'];
    $subscription = $_POST['subscription'];

    // Now, execute your prepared statement with these variables
    $stmt = $conn->prepare("UPDATE cart SET quantity = ?, size = ?, subscription = ? WHERE id = ?");
    $stmt->bind_param("issi", $quantity, $size, $subscription, $cart_id);
    $stmt->execute();
  }

  
  // Refresh page to reflect changes
  header("Location: shopping cart.php");
  exit;
}

// Fetch cart items after handling POST to ensure updated data is fetched
// Fetch cart items
$cartQuery = "SELECT c.id as cart_id,c.product_id, p.*, c.quantity, c.size, c.subscription FROM products p INNER JOIN cart c ON p.id = c.product_id WHERE c.user_id = ?";
$stmt = $conn->prepare($cartQuery);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$cartItems = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);


// Calculate total price
$totalPrice = 0;
foreach ($cartItems as $item) {
  $totalPrice += $item['price'] * $item['quantity'];
}

// Fetch user's address and other details
$addressQuery = "SELECT full_name, street_address, phone_number FROM users WHERE id = ?";
$addressStmt = $conn->prepare($addressQuery);
$addressStmt->bind_param("i", $user_id);
$addressStmt->execute();
$addressResult = $addressStmt->get_result();
$userAddress = $addressResult->fetch_assoc();

$daysToAdd = 7;
$order_date = date_create();
$order_date->format('Y-m-d');

date_add($order_date, date_interval_create_from_date_string("$daysToAdd days"));
$delivery_date = $order_date->format('Y-m-d');
$status = 'Paid';
$payment = 'Gcash';
$active = 'on going';
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>View Cart</title>
  <link rel="icon" type="image/x-icon" href="Image/furco_logo.png">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel="stylesheet" href="Style/bootstrap.min.css">
  <link rel="stylesheet" href="Style/nav.css">
  <link rel="stylesheet" href="Style/shoppingcartstyle.css">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
  <script src="https://checkoutshopper-live.adyen.com/checkoutshopper/sdk/5.63.0/adyen.js" integrity="sha384-wEt/Yz/g97VSgMpNDVCPTyr8FYuIpeOgh42UNr346/yK3z2yfaIixeuLWXG6q0XU" crossorigin="anonymous"></script>

  <link rel="stylesheet" href="https://checkoutshopper-live.adyen.com/checkoutshopper/sdk/5.63.0/adyen.css" integrity="sha384-Dk62669n9Ic7V6K8X7MBAOEZ5IQ9Qq29nW/zPkfwg1ghqyZLiuSc5QYQJ6M72iNR" crossorigin="anonymous">

</head>

<body>
  <div class="navbar">
    <img src="Image/furco_logo.png" alt="FURCO Paw Logo" class="logo">
    <h1>FURCO</h1>
    <div class="search-container">
      <form action="search.php" method="get">
        <img src="Image/furco_search.png" alt="Search" class="search-icon">
        <input type="search" name="query" placeholder="Search" required>
      </form>
    </div>
    <?php require_once("Php/navigation.php"); ?>
  </div>

  <div class="container mt-5 p-3 rounded cart" id="cartcontainer">
    <div class="row">
      <div class="col-md-8">
        <h6 class="mb-0">Shopping cart</h6>
        <div>You have <?= is_array($cartItems) ? count($cartItems) : 0 ?> items in your cart</div>
        <?php if (is_array($cartItems)) : ?>
          <?php foreach ($cartItems as $item) : ?>

            <!-- Shopping Cart container -->
            <div class="item-container mt-3 p-2 rounded">

              <div class="item-details">

                <form action="shopping cart.php" method="post">
                  <input type="hidden" name="cart_id" value="<?= $item['cart_id'] ?>">


                  <div class="d-flex justify-content-between align-items-center mt-3 p-2 items rounded" id="product-details">
                    <div class="d-flex flex-row"><img class="rounded" width="50" src="<?= htmlspecialchars($item['image']) ?>" alt="<?= htmlspecialchars($item['name']) ?>">
                      <div class="ml-2"><span class="font-weight-bold d-block"><?= htmlspecialchars($item['name']) ?></span><span class="spec"><?= htmlspecialchars($item['brand']) ?></span></div>
                    </div>

                    <select name="size" id="size" class="form-control form-control-1" width=50>
                      <option value="small" <?= $item['size'] === 'small' ? 'selected' : '' ?>>Small</option>
                      <option value="medium" <?= $item['size'] === 'medium' ? 'selected' : '' ?>>Medium</option>
                      <option value="large" <?= $item['size'] === 'large' ? 'selected' : '' ?>>Large</option>
                    </select>

                    <select name="subscription" id="subscription" class="form-control form-control-2">
                      <option value="Every Week" <?= $item['subscription'] === 'Every Week' ? 'selected' : '' ?>>Every Week</option>
                      <option value="Every 2 Weeks" <?= $item['subscription'] === 'Every 2 Weeks' ? 'selected' : '' ?>>Every 2 Weeks</option>
                      <option value="Every 3 Weeks" <?= $item['subscription'] === 'Every 3 Weeks' ? 'selected' : '' ?>>Every 3 Weeks</option>
                      <option value="Monthly" <?= $item['subscription'] === 'Monthly' ? 'selected' : '' ?>>Monthly</option>
                    </select>
                    <div class="d-flex flex-row align-items-center">
                      <input type="number" name="quantity" class="form-control form-control-3" value="<?= $item['quantity'] ?>" onblur="updateQuantity(<?= $item['cart_id'] ?>)">
                    </div><span class="d-block ml-5 font-weight-bold">&#8369;<?= number_format($item['price'], 2) ?>
                    </span><button type="submit" name="remove" class="fa fa-trash-o ml-3 text-black-50" style="border: none; background: none;"></button>
                    <button type="submit" name="update" class="btn btn-info">Update</button>
                  </div>
                </form>
              </div>
            </div>

            <!-- Payment Method container-->
          <?php endforeach; ?>
        <?php endif; ?>
      </div>
      <div class="col-md-4">
        <div class="delivery-address-container">
          <div class="delivery-address-header">
            <h2>Delivery Address</h2>
            <!-- Redirect to user_profile.php when the button is clicked -->
            <button onclick="window.location.href='user profile.php'" class="add-address-button">EDIT</button>
          </div>
          <!-- Display the user's full name, phone number, and street address from the database -->
          <div class="delivery-address-details">
            <div class="address-name"><?= htmlspecialchars($userAddress['full_name'] ?? '') ?></div>
            <div class="address-line"><?= htmlspecialchars($userAddress['street_address'] ?? '') ?></div>
            <div class="address-phone"><?= htmlspecialchars($userAddress['phone_number'] ?? '') ?></div>
          </div>
        </div>
        <div class="payment-info">
          <?php $totalPrice ?>
          <div id="dropin-container"></div>

        </div>
      </div>
    </div>
  </div>
  <script>
    const configuration = {
      environment: 'test', // Change to 'live' for the live environment.
      clientKey: 'test_XUJBMLHLFJCWFHUTWKV6ZKKGYQX2QOAH', // Public key used for client-side authentication: https://docs.adyen.com/development-resources/client-side-authentication
      analytics: {
        enabled: true // Set to false to not send analytics data to Adyen.
      },
      session: <?php echo getCheckoutSession($totalPrice) ?>,
      onPaymentCompleted: (result, component) => {
        console.info(result, component);
        <?php echo checkout($user_id,date_create()->format('Y-m-d'),$payment,$userAddress['street_address'],$delivery_date,$status,$cartItems,$totalPrice,$active)?>
      },
      onError: (error, component) => {
        console.error(error.name, error.message, error.stack, component);
      },
      paymentMethodsConfiguration: {
        card: {
          hasHolderName: true,
          holderNameRequired: true,
        }
      },
    };

    const loadAdyen = async () => {
      const checkout = await AdyenCheckout(configuration);
      // Create an instance of Drop-in and mount it to the container you created.
      const dropinComponent = checkout.create('dropin').mount('#dropin-container');
    }
    loadAdyen().then((x) => {
      console.log('loaded adyen')
    })
  </script>
  <?= template_footer() ?>
</html>