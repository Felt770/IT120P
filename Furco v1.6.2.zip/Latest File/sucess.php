<?php
include('Php/functions.php'); 
include('Php/checkout.php');
$conn = db_connect();
$user_id = $_SESSION['user_id'] ?? 0;
echo clearCart($user_id,$conn);
?>

<html>
  <head>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link href="https://fonts.googleapis.com/css?family=Nunito+Sans:400,400i,700,900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="Style/succes.css">

  </head>
 
    <body>
</div>
      <div class="card">
      <div style="border-radius:200px; height:200px; width:200px; background: #F8FAF5; margin:0 auto;">
        <i class="checkmark">✓</i>
      </div>
        <h1>Success</h1> 
        <p>We received your purchase request;<br/> we'll be in touch shortly!</p>
        <button><a href="home.php">Return</button></a>
      </div>
    </body>
</html>