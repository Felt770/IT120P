<?php
function countCartItems($conn, $user_id) {
    $stmt = $conn->prepare("SELECT SUM(qty) AS total_items FROM shopping_cart_item WHERE cart_id = (SELECT id FROM shopping_cart WHERE user_id = ?)");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    return $row['total_items'] ?? 0;
}

if (isLoggedIn()) {
    $user_id = $_SESSION['user_id'];
     
    echo '<a href="Home.php">Home</a>';
    echo '<a href="Products.php">Products</a>';

    if (isAdmin()) {
        echo '<a href="order_history.php">My Order</a>';
        echo '<a href="Php/logout.php" class="logout">Logout</a>';
    } else {
        $cartItemCount = countCartItems($conn, $user_id);  
        echo '<a href="subscriptions.php">Subscription</a>';
        echo '<a href="user_history.php">My Order</a>';
        echo '<a href="shopping_cart.php" class="cart-button"><img src="Image/furco_cart.png" alt="FURCO Cart" class="cart"><span class="cart-count">' . $cartItemCount . '</span></a>';
        echo '<div class="dropdown">
                  <button class="dropbtn"><img src="Image/furco_profile.png" alt="Profile" class="profile"></button>
                  <div class="dropdown-content">
                      <a href="user_profile.php">User Profile</a>
                      <a href="Php/logout.php">Logout</a>
                  </div>
              </div>';
    }
} else {
    echo '<a href="Home.php">Home</a>';
    echo '<a href="Products.php">Products</a>';
    $currentPage = basename($_SERVER['PHP_SELF']);
    if ($currentPage == 'login.php') {
        echo '<a href="register.php" class="login">Register</a>';
    } else {
        echo '<a href="login.php" class="login">Login</a>';
    }
}
?>