-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 03, 2024 at 02:49 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `furco`
--

-- --------------------------------------------------------

--
-- Table structure for table `address`
--

CREATE TABLE `address` (
  `id` int(11) NOT NULL,
  `street_address` varchar(150) NOT NULL,
  `city` varchar(100) NOT NULL,
  `region` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `address`
--

INSERT INTO `address` (`id`, `street_address`, `city`, `region`) VALUES
(1, 'yaystreet', 'test', 'test'),
(2, 'yaystreet', 'test', 'del note'),
(3, 'userstreet', 'davao', 'del note'),
(4, 'Admin Street', 'Admin', 'Admin');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `order_date` datetime NOT NULL,
  `payment_method_id` int(11) NOT NULL,
  `shipping_address_id` int(11) NOT NULL,
  `order_total` float NOT NULL,
  `delivery_date` date NOT NULL,
  `order_status_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `order_date`, `payment_method_id`, `shipping_address_id`, `order_total`, `delivery_date`, `order_status_id`) VALUES
(16, 1, '2024-05-03 20:43:49', 19, 1, 1588, '2024-05-06', 4);

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `order_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_items`
--

INSERT INTO `order_items` (`id`, `product_id`, `qty`, `order_id`) VALUES
(20, 28, 3, 16),
(21, 22, 1, 16),
(22, 27, 1, 16);

-- --------------------------------------------------------

--
-- Table structure for table `order_status`
--

CREATE TABLE `order_status` (
  `id` int(11) NOT NULL,
  `status` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_status`
--

INSERT INTO `order_status` (`id`, `status`) VALUES
(1, 'Ordered'),
(2, 'Shipped'),
(3, 'On the way'),
(4, 'Delivered');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL,
  `description` varchar(2000) DEFAULT NULL,
  `price` float NOT NULL,
  `pet_type` varchar(200) DEFAULT NULL,
  `product_type` varchar(200) DEFAULT NULL,
  `brand` mediumtext DEFAULT NULL,
  `is_for_subscription` tinyint(1) NOT NULL,
  `image_url` varchar(300) DEFAULT NULL,
  `size_options` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `description`, `price`, `pet_type`, `product_type`, `brand`, `is_for_subscription`, `image_url`, `size_options`) VALUES
(17, 'High Energy', 'Super-premium dog food for puppies, pregnant and nursing females, for show dogs and working dogs in a satisfying lamb and beef flavor', 840, NULL, 'Dog Food', 'Vitality', 1, ' https://zbga.shopsuki.ph/cdn/shop/files/9327556000171_1024x.jpg?v=1703675402', 'Medium:840'),
(18, 'Value Meal Adult Dry Dog', 'High quality Australian lamb & beef dog food for adult dogs', 550, NULL, 'Dog Food', 'Vitality', 1, 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQDWyyMm1Fz_0XG2_a8IKQ9DYvVi2FZdGmC0VmkmWZ5YQ&s', 'Medium:550'),
(19, 'Value Meal Puppy Small Bites Dry Dog Food', 'High quality Australian lamb & beef dog food for puppies', 630, NULL, 'Dog Food', 'Vitality', 1, 'https://www.petcultureph.com/cdn/shop/files/Vitalityvaluemealpuppy3kg.png?v=1695112016&width=1445', 'Medium:630'),
(20, 'Adult Beef Wet Dog Food', 'Not only does Pedigree Adult Beef Wet Dog Food provide a hearty and flavorful meal, but it also offers balanced nutrition to keep your dog energized and happy throughout the day. Whether served alone or mixed with dry food, this savory recipe is sure to be a favorite among even the pickiest eaters.', 120, NULL, 'Dog Food', 'Pedigree', 1, 'https://cdn.discordapp.com/attachments/1085899625061429285/1235924325580800060/pedigreebeefwet.png?ex=663623b9&is=6634d239&hm=1e82a39afe3a5ff04d7f04c56b658a121be394f34994fc4427f6d4495d86d079&', 'Small:120'),
(21, 'Adult Beef Chunks Dog Food', 'Crafted with a blend of vitamins, minerals, and antioxidants, Pedigree Adult Beef Chunks Dog Food supports immune health, helping your furry friend thrive day after day. Each serving is fortified with omega-6 fatty acids, promoting healthy skin and a shiny coat, while the crunchy texture of the chunks adds excitement to mealtime.', 45, NULL, 'Dog Food', 'Pedigree', 1, 'https://cdn.discordapp.com/attachments/1085899625061429285/1235924961731018833/pedigreeadultchunks.png?ex=66362451&is=6634d2d1&hm=3cf43fd7b85904ec7c73b871f48947ca04d5b0c8150cc6747dc56799380caa92&', 'Small:45'),
(22, 'Dry Adult Beef & Vegetables Flavour', 'The crunchy texture of the kibble helps to keep your dog\'s teeth clean and healthy, while the savory beef and vegetable flavors make mealtime enjoyable. Plus, Pedigree\'s commitment to quality means you can trust that every bite is packed with nutrition and flavor.', 500, NULL, 'Dog Food', 'Pedigree', 1, 'https://cdn.discordapp.com/attachments/1085899625061429285/1235927099236417557/pedigreevege.png?ex=6636264e&is=6634d4ce&hm=c6be18e0ac14792708516323fd571dc5d78014204a0622855da6aeda87d5f60c&', 'Medium:500'),
(23, 'Dry Cat Food Kibble', 'With a focus on digestive health, skin and coat care, and urinary tract support, ROYAL CANIN dry cat food kibble offers comprehensive nutrition to keep your cat happy and healthy. Plus, the crunchy texture of the kibble helps to promote dental health by reducing plaque and tartar buildup.', 250, NULL, 'Cat Food', 'Royal Canin', 1, 'https://cdn.discordapp.com/attachments/1085899625061429285/1235927920191471676/royalcanincatkibble.png?ex=66362712&is=6634d592&hm=3769a8aed4b73ce788fe37077f7c104b1e5d871d1f2405ec616fccdf13ac2c1f&', 'Medium:250'),
(24, 'Breed Health Nutrition Adult Maltese Dry Dog Food', 'With a focus on breed-specific needs, such as maintaining a healthy coat and supporting skin health, Royal Canin Breed Health Nutrition Adult Maltese Dry Dog Food provides targeted nutrition to keep your Maltese happy and thriving. Plus, its delicious flavor ensures mealtime is always a delightful experience for your furry companion.', 800, NULL, 'Dog Food', 'Royal Canin', 1, 'https://cdn.discordapp.com/attachments/1085899625061429285/1235928574041653389/royalcanindrydog.png?ex=663627ae&is=6634d62e&hm=cd3a3d3c40e5df016bb8923622a0f51dbb8c310b2dffe05c9cef3a51064bf895&', 'Medium:800'),
(25, 'Adult Beef Dog Food', 'The irresistible aroma and mouthwatering taste of beef make Good Boy Adult Beef Dog Food a favorite among dogs of all breeds and sizes. Plus, its crunchy texture helps to clean teeth and freshen breath with every bite, promoting dental health and hygiene.', 1400, NULL, 'Dog Food', 'Good Boy', 1, 'https://cdn.discordapp.com/attachments/1085899625061429285/1235929137148067860/goodboyadult.png?ex=66362834&is=6634d6b4&hm=79e6c87d6a8c61b868ac5063effe7734fc06c1c89dfc3ff0b1128f7aa6197361&', 'Large:1400'),
(26, 'Classic Beef Flavor Dog Food', 'Good Boy Classic Maintenance Dog Food features a carefully selected blend of proteins, carbohydrates, and fats to support optimal energy levels and maintain lean muscle mass. Formulated with vitamins and minerals, including omega fatty acids, this recipe promotes healthy skin, a shiny coat, and overall vitality.', 1300, NULL, 'Dog Food', 'Good Boy', 1, 'https://cdn.discordapp.com/attachments/1085899625061429285/1235929825794064444/goodboyclassic.png?ex=663628d8&is=6634d758&hm=fc1aca142541ecfc5214b598b04d27c0733b55a78f732ebbe26e4f36ab4ac00c&', 'Large:1300'),
(27, 'Little Small Breed Adult Dog Food', 'With real meat as the primary ingredient, Good Boy Little Small Breed Adult Dog Food provides essential protein to maintain strong muscles and overall well-being. The small kibble size is specially crafted to accommodate tiny mouths and promote chewing, aiding in dental health and hygiene.', 730, NULL, 'Dog Food', 'Good Boy', 1, 'https://cdn.discordapp.com/attachments/1085899625061429285/1235930397305606214/goodboysmall.png?ex=66362961&is=6634d7e1&hm=0ff5c4d97cede83c23aa62182da939c30c36818e7002541b97fa944af0542544&', 'Medium:730'),
(28, 'Happy Tummy Treats Dog Food', 'Crafted with premium-quality beef as the main ingredient, these delectable snacks are packed with protein to support strong muscles and overall well-being. Each bite-sized treat is carefully formulated to be gentle on your dog\'s stomach, making them perfect for pups with sensitive digestive systems. \r\n', 100, NULL, 'Dog Food', 'Dr. Shiba', 1, 'https://cdn.discordapp.com/attachments/1085899625061429285/1235931227148779611/happytummy.png?ex=66362a27&is=6634d8a7&hm=16ff0de9fbb72b139da71372f87768513c2517ccdc4a37146becdcffebb4fc44&', 'Small:100'),
(29, 'Pro Immune Treats Dog Food', 'Each bite-sized treat is packed with premium-quality beef, providing essential protein for strong muscles and energy. Additionally, the Pro Immune formula contains immune-boosting ingredients such as vitamins, minerals, and antioxidants to strengthen your dog\'s defenses against common ailments.', 95, NULL, 'Dog Food', 'Dr. Shiba', 1, 'https://cdn.discordapp.com/attachments/1085899625061429285/1235932069687853129/proimmune.png?ex=66362aef&is=6634d96f&hm=28057904c6cc323c8687c2b9691b004724a93927bbf03b690a02b01d6c169a44&', 'Small:95');

-- --------------------------------------------------------

--
-- Table structure for table `shopping_cart`
--

CREATE TABLE `shopping_cart` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `shopping_cart`
--

INSERT INTO `shopping_cart` (`id`, `user_id`) VALUES
(6, 1);

-- --------------------------------------------------------

--
-- Table structure for table `shopping_cart_item`
--

CREATE TABLE `shopping_cart_item` (
  `id` int(11) NOT NULL,
  `cart_id` int(11) DEFAULT NULL,
  `product_item_id` int(11) DEFAULT NULL,
  `qty` int(11) NOT NULL,
  `size` varchar(50) DEFAULT NULL,
  `subscription` varchar(100) DEFAULT NULL,
  `price` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `subscriptions`
--

CREATE TABLE `subscriptions` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `address_id` int(11) NOT NULL,
  `payment_method_id` int(11) NOT NULL,
  `start_date` date NOT NULL,
  `frequency` varchar(100) NOT NULL,
  `qty` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `subscriptions`
--

INSERT INTO `subscriptions` (`id`, `user_id`, `product_id`, `address_id`, `payment_method_id`, `start_date`, `frequency`, `qty`) VALUES
(19, 1, 28, 1, 19, '2024-05-03', '1 Week', 3),
(20, 1, 22, 1, 19, '2024-05-03', '1 Month', 1),
(21, 1, 27, 1, 19, '2024-05-03', '1 Week', 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `full_name` varchar(50) NOT NULL,
  `email_address` varchar(200) NOT NULL,
  `password` varchar(100) NOT NULL,
  `phone_number` varchar(15) NOT NULL,
  `is_admin` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `full_name`, `email_address`, `password`, `phone_number`, `is_admin`) VALUES
(1, 'Jom', 'jbmanongas@gmail.com', '$2y$10$Kv4we/lx4l7nW1OunHH1eOblHRGNoUDB9XMAQZFj5HPwNU5FCVGt2', '09999340898', 0),
(3, 'user', 'user@gmail.com', '$2y$10$UWG1hh5cNGwtc14g.Ygm3uscwE5XSvq9eLQJ3F8fCJjVExx20WX0G', '09999340898', 0),
(4, 'admin', 'admin@gmail.com', '$2y$10$vY91bJ1jcWbY6aHVeLDaTOAi7If5oab01cvwSo7MbCMr5eP99uN2i', '09999340898', 1);

-- --------------------------------------------------------

--
-- Table structure for table `user_address`
--

CREATE TABLE `user_address` (
  `user_id` int(11) NOT NULL,
  `address_id` int(11) NOT NULL,
  `is_default` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_address`
--

INSERT INTO `user_address` (`user_id`, `address_id`, `is_default`) VALUES
(1, 1, 1),
(3, 3, 1),
(4, 4, 1);

-- --------------------------------------------------------

--
-- Table structure for table `user_payment_method`
--

CREATE TABLE `user_payment_method` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `provider` varchar(100) NOT NULL,
  `card_name` varchar(100) NOT NULL,
  `card_number` varchar(100) NOT NULL,
  `expiration_date` varchar(10) NOT NULL,
  `cvv` varchar(10) NOT NULL,
  `is_default` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_payment_method`
--

INSERT INTO `user_payment_method` (`id`, `user_id`, `provider`, `card_name`, `card_number`, `expiration_date`, `cvv`, `is_default`) VALUES
(19, 1, 'Gcash', 'John Smith', '123456789012', '02/30', '123', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `address`
--
ALTER TABLE `address`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_status` (`order_status_id`),
  ADD KEY `payment_method_orders` (`payment_method_id`),
  ADD KEY `shipping_address_orders` (`shipping_address_id`),
  ADD KEY `users_orders` (`user_id`);

--
-- Indexes for table `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_order_items` (`product_id`);

--
-- Indexes for table `order_status`
--
ALTER TABLE `order_status`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `shopping_cart`
--
ALTER TABLE `shopping_cart`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cart` (`user_id`);

--
-- Indexes for table `shopping_cart_item`
--
ALTER TABLE `shopping_cart_item`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cart_id` (`cart_id`),
  ADD KEY `product_id` (`product_item_id`);

--
-- Indexes for table `subscriptions`
--
ALTER TABLE `subscriptions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `products` (`product_id`),
  ADD KEY `address_id` (`address_id`),
  ADD KEY `payment_method_id` (`payment_method_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_address`
--
ALTER TABLE `user_address`
  ADD PRIMARY KEY (`user_id`,`address_id`),
  ADD KEY `address` (`address_id`);

--
-- Indexes for table `user_payment_method`
--
ALTER TABLE `user_payment_method`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `address`
--
ALTER TABLE `address`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `order_items`
--
ALTER TABLE `order_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `order_status`
--
ALTER TABLE `order_status`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `shopping_cart`
--
ALTER TABLE `shopping_cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `shopping_cart_item`
--
ALTER TABLE `shopping_cart_item`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `subscriptions`
--
ALTER TABLE `subscriptions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `user_payment_method`
--
ALTER TABLE `user_payment_method`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `order_status` FOREIGN KEY (`order_status_id`) REFERENCES `order_status` (`id`),
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `orders_ibfk_2` FOREIGN KEY (`shipping_address_id`) REFERENCES `address` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `payment_method_orders` FOREIGN KEY (`payment_method_id`) REFERENCES `user_payment_method` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `shipping_address_orders` FOREIGN KEY (`shipping_address_id`) REFERENCES `address` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `users_orders` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `order_items`
--
ALTER TABLE `order_items`
  ADD CONSTRAINT `product_order_items` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `shopping_cart`
--
ALTER TABLE `shopping_cart`
  ADD CONSTRAINT `cart` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `shopping_cart_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `shopping_cart_item`
--
ALTER TABLE `shopping_cart_item`
  ADD CONSTRAINT `cart_id` FOREIGN KEY (`cart_id`) REFERENCES `shopping_cart` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `product_id` FOREIGN KEY (`product_item_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `shopping_cart_item_ibfk_1` FOREIGN KEY (`cart_id`) REFERENCES `shopping_cart` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `shopping_cart_item_ibfk_2` FOREIGN KEY (`product_item_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `subscriptions`
--
ALTER TABLE `subscriptions`
  ADD CONSTRAINT `address_id` FOREIGN KEY (`address_id`) REFERENCES `address` (`id`),
  ADD CONSTRAINT `payment_method_id` FOREIGN KEY (`payment_method_id`) REFERENCES `user_payment_method` (`id`),
  ADD CONSTRAINT `products` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
  ADD CONSTRAINT `user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `user_address`
--
ALTER TABLE `user_address`
  ADD CONSTRAINT `address` FOREIGN KEY (`address_id`) REFERENCES `address` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `user_address_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `user_address_ibfk_2` FOREIGN KEY (`address_id`) REFERENCES `address` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `user_payment_method`
--
ALTER TABLE `user_payment_method`
  ADD CONSTRAINT `user_payment_method_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
