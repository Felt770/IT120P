<?php
include('Php/functions.php');
$conn = db_connect();
$id = $_GET['id'] ?? null;

if (!$id) {
    header('Location: subscriptions.php');
    exit;
}

// Fetch subscription details from the database
$stmt = $conn->prepare("SELECT s.*, p.name, p.description, p.brand, p.image_url, u.full_name, a.street_address, a.city, a.region, pm.card_number, pm.provider FROM subscriptions s JOIN products p ON s.product_id = p.id JOIN users u ON s.user_id = u.id JOIN address a ON s.address_id = a.id JOIN user_payment_method pm ON s.payment_method_id = pm.id WHERE s.id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$subscription = $stmt->get_result()->fetch_assoc();

// Calculate next delivery date based on frequency and start date
$nextDelivery = new DateTime($subscription['start_date']);
$nextDelivery->modify('+' . $subscription['frequency']);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['skip'])) {
        // Skip the next delivery
        $nextDelivery->modify('+' . $subscription['frequency']);
        $update = $conn->prepare("UPDATE subscriptions SET start_date = ? WHERE id = ?");
        $update->bind_param("si", $nextDelivery->format('Y-m-d'), $id);
        $update->execute();
    } elseif (isset($_POST['update'])) {
        // Update frequency and quantity
        $newFreq = $_POST['subscription-freq'];
        $newQty = $_POST['subscription-qty'];
        $update = $conn->prepare("UPDATE subscriptions SET frequency = ?, qty = ? WHERE id = ?");
        $update->bind_param("sii", $newFreq, $newQty, $id);
        $update->execute();
    } elseif (isset($_POST['cancel'])) {
        // Cancel subscription
        $delete = $conn->prepare("DELETE FROM subscriptions WHERE id = ?");
        $delete->bind_param("i", $id);
        $delete->execute();
        header('Location: subscriptions.php');
        exit;
    }
    // Reload page to reflect changes
    header('Location: subscription_view.php?id=' . $id);
    exit;
}

// Display the next delivery date
$displayDate = $nextDelivery->format('Y-m-d');


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Subscription Details</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="Style/bootstrap.min.css">
    <link rel="stylesheet" href="Style/global.css">
    <link rel="stylesheet" href="Style/subscription-view-style.css">
    <link rel="icon" type="image/x-icon" href="Image/furco_logo.png">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
    <script>
        function confirmAction(actionName) {
            return confirm("Are you sure you want to " + actionName + "?");
        }
    </script>

    <style>
        .subscription-img {
        margin-left: 50px;
        width: 300px;
        }

        .subscription-img img{
        width: 300px;
        border-radius: 5px;
        }

    </style>
</head>

<body>
    <div class="navbar">
        <img src="Image/furcologo.svg" alt="FURCO Paw Logo" class="logo">
        <h1>FURCO</h1>
        <div class="search-container">
            <form action="search.php" method="get">
                <img src="Image/furco_search.png" alt="Search" class="search-icon">
                <input type="search" name="query" placeholder="Search" required>
            </form>
        </div>
        <?php require_once("Php/navigation.php"); ?>
    </div>

    <main>
        <h1 class="title">Subscription Details</h1>
        <a href="subscriptions.php"><button id="back-btn">BACK</button></a>

        <div class="subscription-details">
            <div class="subscription-info">
                <h2><b><?= htmlspecialchars($subscription['brand']) ?></b></h2>
                <h2 style="margin-bottom: 20px;"><?= htmlspecialchars($subscription['name']) ?></h2>
                <p class="desc"><?= htmlspecialchars($subscription['description']) ?></p>
                <span>Next Delivery Will Arrive By</span>
                <p><?= $displayDate ?></p>
                <form method="post" onsubmit="return confirmAction('skip the next delivery')"><button type="submit" name="skip" id="skip-btn">SKIP NEXT DELIVERY</button></form>
            </div>
            <div class="subscription-img">
                <img src="<?= htmlspecialchars($subscription['image_url']) ?>" alt="<?= htmlspecialchars($subscription['name']) ?>">
            </div>
        </div>

        <hr id="hr" align="left">

        <div class="subscription-details">
            <div class="subscription-info">
                <span>Shipping Address</span>
                <a href="user_profile.php" class="change-btn">
                    <button id="change-btn">CHANGE</button>
                </a><br>
                <span><?= htmlspecialchars($subscription['street_address']) ?>, <?= htmlspecialchars($subscription['city']) ?>, <?= htmlspecialchars($subscription['region']) ?></span>
            </div>
        </div>

        <hr id="hr" align="left">

        <div class="subscription-details">
            <div class="subscription-info">
                <span>Payment Method</span><br>
                <span>Card Ending in <?= substr(htmlspecialchars($subscription['card_number']), -4) ?> (<?= htmlspecialchars($subscription['provider']) ?>)</span>
            </div>
        </div>

        <hr id="hr" align="left">

        <div class="subscription-details">
            <div class="subscription-info">
                <span>Change Your Delivery Schedule</span><br>
                <form method="post" onsubmit="return confirmAction('save these changes')">
                    <input type="number" id="sub-qty" name="subscription-qty" value="<?= htmlspecialchars($subscription['qty']) ?>" min="1" max="10" style="width: 60px; height: 21px; padding: 10px; margin-right: 10px; border-radius: 5px; background-color: #fff; border: 1px solid #ffa451;">
                    <select id="sub-freq" name="subscription-freq">
                        <option value="1 Week" <?= ($subscription['frequency'] == '1 Week' ? 'selected' : '') ?>>Every 1 Week</option>
                        <option value="2 Weeks" <?= ($subscription['frequency'] == '2 Weeks' ? 'selected' : '') ?>>Every 2 Weeks</option>
                        <option value="3 Weeks" <?= ($subscription['frequency'] == '3 Weeks' ? 'selected' : '') ?>>Every 3 Weeks</option>
                        <option value="1 Month" <?= ($subscription['frequency'] == '1 Month' ? 'selected' : '') ?>>Every 1 Month</option>
                        <option value="5 Weeks" <?= ($subscription['frequency'] == '5 Weeks' ? 'selected' : '') ?>>Every 5 Weeks</option>
                        <option value="6 Weeks" <?= ($subscription['frequency'] == '6 Weeks' ? 'selected' : '') ?>>Every 6 Weeks</option>
                        <option value="7 Weeks" <?= ($subscription['frequency'] == '7 Weeks' ? 'selected' : '') ?>>Every 7 Weeks</option>
                        <option value="2 Months" <?= ($subscription['frequency'] == '2 Months' ? 'selected' : '') ?>>Every 2 Months</option>
                    </select>
                    <br>
                    <button type="submit" name="update" id="save-btn">SAVE CHANGES</button>
                </form>
            </div>
        </div>
        <hr id="hr" align="left">

        <form method="post" onsubmit="return confirmAction('cancel this subscription')">
            <button type="submit" name="cancel" id="cancel-btn">CANCEL SUBSCRIPTION</button>
        </form>
    </main>

    <?= footer() ?>
</body>

</html>