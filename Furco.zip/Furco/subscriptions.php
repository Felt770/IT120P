<?php
include('Php/functions.php');
$conn = db_connect();
$num_subscription_on_each_page = 8;

$current_page = isset($_GET['p']) && is_numeric($_GET['p']) ? (int)$_GET['p'] : 1;
$offset = ($current_page - 1) * $num_subscription_on_each_page;

$stmt = $conn->prepare("SELECT s.id, s.qty, p.name, p.brand, p.image_url AS image, p.price FROM subscriptions s JOIN products p ON s.product_id = p.id ORDER BY s.id DESC LIMIT ?, ?" );
$stmt->bind_param("ii", $offset, $num_subscription_on_each_page);
$stmt->execute();
$subscriptions = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

$total_subscription_res = $conn->query("SELECT COUNT(*) as total FROM subscriptions");
$total_subscription = $total_subscription_res->fetch_assoc()['total'];




?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Subscriptions</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="Style/bootstrap.min.css">
    <link rel="stylesheet" href="Style/global.css">
    <link rel="stylesheet" href="Style/subscriptions-style.css">
    <link rel="icon" type="image/x-icon" href="Image/furco_logo.png">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

    <style>
        

    </style>
</head>

<body>
    <div class="navbar">
        <img src="Image/furcologo.svg" alt="FURCO Paw Logo" class="logo">
        <h1>FURCO</h1>
        <div class="search-container">
            <form action="search.php" method="get">
                <img src="Image/furco_search.png" alt="Search" class="search-icon">
                <input type="search" name="query" placeholder="Search" required>
            </form>
        </div>
        <?php require_once("Php/navigation.php"); ?>
    </div>

    <main>
        <h1>Subscriptions</h1>
        <section class="subscription-list">
            <?php foreach ($subscriptions as $subscription) : ?>
                <a href="subscription_view.php?id=<?= htmlspecialchars($subscription['id']) ?>" class="subscription-item-link">
                    <div class="subscription-item">
                        <img src="<?= htmlspecialchars($subscription['image']) ?>" alt="<?= htmlspecialchars($subscription['name']) ?>" class="subscription-item-image">
                        <div class="subscription-desc">
                            <h3><?= htmlspecialchars($subscription['brand']) ?></h3>
                            <p><?= htmlspecialchars($subscription['name']) ?></p>
                            <div class="price-details">
                                <span class="total-price">₱<?= number_format($subscription['price'], 2) ?></span>
                                <span class="quantity"> (Qty: <?= $subscription['qty'] ?>)</span>
                            </div>
                        </div>
                    </div>
                </a>
            <?php endforeach; ?>
        </section>

        <div class="buttons">
            <?php if ($current_page > 1) : ?>
                <a href="subscriptions.php?p=<?= $current_page - 1 ?>" class="button">Prev</a>
            <?php endif; ?>
            <?php if ($total_subscription > ($current_page * $num_subscription_on_each_page)) : ?>
                <a href="subscriptions.php?p=<?= $current_page + 1 ?>" class="button">Next</a>
            <?php endif; ?>
        </div>
        <br>

    </main>

    <?= footer() ?>
</body>

</html>