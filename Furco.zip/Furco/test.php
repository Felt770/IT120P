<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Test Checkout</title>
</head>
<body>
<button id="checkoutButton" class="btn btn-success">Checkout</button>
<script>
document.getElementById('checkoutButton').addEventListener('click', finalizeCheckout);

function finalizeCheckout() {
  alert("Function is defined and button is working.");
      if (confirm("Are you sure you want to finalize this order?")) {
        fetch('Php/testcheckout.php', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: 'action=checkout'
          })
          .then(response => {
            if (!response.ok) {
              throw new Error('Network response was not ok');
            }
            return response.json();
          })
          .then(data => {
            if (data.success) {
              alert("Your order has been placed successfully!");
              window.location.href = "success.php"; // Redirect to a confirmation page
            } else {
              alert("There was an issue with your order. Please try again.");
            }
          })
          .catch(error => {
            console.error('Error:', error);
            alert('There was an error processing your checkout.');
          });
    }
}
</script>
</body>
</html>
