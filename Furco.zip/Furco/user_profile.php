<?php
include('Php/functions.php');
$userId = $_SESSION['user_id'];
$conn = db_connect();
$userData = getUserData($conn, $userId);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $fullName = $_POST['fullName'] ?? '';
  $phoneNumber = $_POST['phoneNumber'] ?? '';
  $streetAddress = $_POST['streetAddress'] ?? '';
  $city = $_POST['city'] ?? '';
  $region = $_POST['region'] ?? '';
  $errorMessage = '';

  // Check if any user data has changed
  $hasDataChanged = $fullName !== $_SESSION['full_name'] ||
    $phoneNumber !== $_SESSION['phone_number'] ||
    $streetAddress !== $_SESSION['street_address'] ||
    $city !== $_SESSION['city'] ||
    $region !== $_SESSION['region'];

  // Assume no errors initially
  $passwordUpdateResult = true;
  $result = true;

  if (isset($_POST['changePassword']) && $_POST['changePassword'] === 'yes') {
    $oldPassword = $_POST['oldPassword'] ?? '';
    $newPassword = $_POST['newPassword'] ?? '';
    $currentPasswordHash = getUserPasswordHash($userId);

    if (password_verify($oldPassword, $currentPasswordHash)) {
      $newPasswordHash = password_hash($newPassword, PASSWORD_DEFAULT);
      $passwordUpdateResult = updateUserPassword($conn, $userId, $newPasswordHash);
      if (!$passwordUpdateResult) {
        $errorMessage = "Error updating password.";
      }
    } else {
      $errorMessage = "Incorrect old password.";
      $passwordUpdateResult = false;
    }
  }

  if ($hasDataChanged) {
    $result = updateUserData($conn, $userId, $fullName, $phoneNumber, $streetAddress, $city, $region);
    if (!$result) {
      $errorMessage = "Error updating user data.";
    }
  }

  // Determine overall success
  $allUpdatesSuccessful = $passwordUpdateResult && $result;

  if ($allUpdatesSuccessful) {
    $_SESSION['flash_success'] = 'Profile updated successfully!';
  } else {
    $_SESSION['flash_error'] = $errorMessage ?: 'Failed to update profile. Please try again.';
  }

  header("Location: user_profile.php");
  exit;
}

// Message display and clearing
$successMessage = $_SESSION['flash_success'] ?? '';
unset($_SESSION['flash_success']);

$errorMessage = $_SESSION['flash_error'] ?? '';
unset($_SESSION['flash_error']);
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <title>User Profile</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel="stylesheet" href="Style/bootstrap.min.css">
  <link rel="stylesheet" href="Style/global.css">
  <link rel="stylesheet" href="Style/user profile style.css">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
</head>

<body>
  <div class="navbar">
    <img src="Image/furcologo.svg" alt="FURCO Paw Logo" class="logo">
    <h1>FURCO</h1>
    <div class="search-container">
      <form action="search.php" method="get">
        <img src="Image/furco_search.png" alt="Search" class="search-icon">
        <input type="search" name="query" placeholder="Search" required>
      </form>
    </div>
    <?php require_once("Php/navigation.php"); ?>
  </div>
  <main>
    <div class="container-form">
      <div class="title-container">
        <h2>Edit Profile</h2>
        <img src="Image/user_icon.png" width="100" height="100" alt="User Icon" class="logo">
      </div>
      <?php if (!empty($successMessage)) : ?>
        <div class="alert alert-success"><?php echo $successMessage; ?></div>
      <?php endif; ?>
      <?php if (!empty($errorMessage)) : ?>
        <div class="alert alert-danger"><?php echo $errorMessage; ?></div>
      <?php endif; ?>
      <form method="post">
        <div class="form-group">
          <label for="fullName">Full Name:</label>
          <input type="text" class="form-control" id="fullName" name="fullName" value="<?php echo $userData['full_name'] ?? ''; ?>" required>
        </div>
        <div class="form-group">
          <label for="emailAddress">Email Address:</label>
          <input type="email" class="form-control" id="emailAddress" name="emailAddress" value="<?php echo $userData['email_address'] ?? ''; ?>" readonly>
        </div>
        <div class="form-group">
          <label for="address">Address:</label>
          <input type="text" class="form-control" id="address" name="streetAddress" value="<?php echo $userData['street_address'] ?? ''; ?>" required>
        </div>
        <div class="form-group">
          <label for="city">City:</label>
          <input type="text" class="form-control" id="city" name="city" value="<?php echo $userData['city'] ?? ''; ?>" required>
        </div>
        <div class="form-group">
          <label for="region">Region:</label>
          <input type="text" class="form-control" id="region" name="region" value="<?php echo $userData['region'] ?? ''; ?>" required>
        </div>
        <div class="form-group">
          <label for="contactNumber">Contact Number:</label>
          <input type="tel" class="form-control" id="contactNumber" name="phoneNumber" value="<?php echo $userData['phone_number'] ?? ''; ?>" required>
        </div>
        <!-- Password Change Option --><br>
        <div class="form-group">
          <label>Do you want to change your password?</label>
          <div>
            <input type="radio" id="yes" name="changePassword" value="yes" onclick="togglePasswordFields(true)">
            <label for="yes">Yes</label>
            <input type="radio" id="no" name="changePassword" value="no" checked onclick="togglePasswordFields(false)">
            <label for="no">No</label>
          </div>
        </div>
        <!-- Password Fields -->
        <div id="passwordFields" style="display: none;">
          <div class="form-group">
            <label for="oldPassword">Old Password:</label>
            <input type="password" class="form-control" id="oldPassword" name="oldPassword">
          </div>
          <div class="form-group">
            <label for="newPassword">New Password:</label>
            <input type="password" class="form-control" id="newPassword" name="newPassword">
          </div>
        </div>
        <button type="reset" class="btn btn-secondary">Reset</button>
        <button type="submit" class="btn btn-primary">Save</button>
      </form>
    </div>
  </main>
  <script>
    document.addEventListener("DOMContentLoaded", function() {
      const alerts = document.querySelectorAll('.alert');
      setTimeout(() => {
        alerts.forEach(alert => alert.style.display = 'none');
      }, 5000); // Hides alerts after 5 seconds
    });
  </script>

  <script>
    function togglePasswordFields(show) {
      document.getElementById('passwordFields').style.display = show ? 'block' : 'none';
    }
  </script>
  <?= footer() ?>
</body>

</html>