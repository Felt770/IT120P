<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Tracker</title>
    <link rel="stylesheet" href="Style/nav bar.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.bundle.min.js">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js">
</head>

<body>
<?php
if (!isset($_SESSION['isLoggedIn']) || $_SESSION['isLoggedIn'] !== true) {
  // User is not logged in, hide profile, chart, subscription, and order links
?>
<div class="navbar">
  <img src="Image/furco_logo.png" alt="FURCO Paw Logo" class="logo">
  <h1>FURCO</h1>
  <div class="search-container">
    <img src="Image/furco_search.png" alt="Search" class="search-icon">
    <input type="search" placeholder="Search">
  </div>
  <a href="Home.php">Home</a>
  <a href="Product.php">Products</a>
  <a href="login.php"><button class="sign-in">Sign In</a></button>
</div>
<?php
} else {
  // User is logged in, show all links
?>
<div class="navbar">
  <img src="Image/furco_logo.png" alt="FURCO Paw Logo" class="logo">
  <h1>FURCO</h1>
  <div class="search-container">
    <img src="Image/furco_search.png" alt="Search" class="search-icon">
    <input type="search" placeholder="Search">
  </div>
  <a href="Home.php">Home</a>
  <a href="subscriptions.php">Subscription</a>
  <a href="Product.php">Products</a>
  <a href="Order History page.php">My Order</a>
  <button><img src="Image/furco_cart.png" alt="FURCO Cart" class="cart"></button>
  <button><img src="Image/furco_profile.png" alt="FURCO Profile" class="profile"></button>
</div>
<?php
}
?>
</body>

</html>