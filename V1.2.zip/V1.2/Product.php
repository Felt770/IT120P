<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="Style/Product style.css">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <title>Pet Products</title>
  <link rel="icon" type="image/x-icon" href="Image/furco_logo.png">
</head>
<body>
<div class="navbar">
        <img src="Image/furco_logo.png" alt="FURCO Paw Logo" class="logo">
        <h1>FURCO</h1>
        <div class="search-container">
            <img src="Image/furco_search.png" alt="Search" class="search-icon">
            <input type="search" placeholder="Search">
        </div>
        <a href="Home.php">Home</a>
        <a href="#">Subscription</a>
        <a href="Product.php">Products</a>
        <a href="Order History page.php">My Order</a>
        <button><img src="Image/furco_cart.png" alt="FURCO Cart" class="cart"></button>
        <button><img src="Image/furco_profile.png" alt="FURCO Profile" class="profile"></button>
    </div>    
  <main>
    <section class="product-list">
    <div class="product-item">
    <a href="Tracker page.php"><img src="Image/furco_pawprints.png" alt="Whiskas Ocean Fish Flavor Loaf">
        <h3>Whiskas Ocean Fish Flavor Loaf</h3>
        <p>Classic</p>
        <span>P80</span>
    </a>
      </div>
      <div class="product-item">
    <a href="Tracker page.php"><img src="Image/furco_pawprints.png" alt="Whiskas Ocean Fish Flavor Loaf">
        <h3>Whiskas Ocean Fish Flavor Loaf</h3>
        <p>Classic</p>
        <span>P80</span>
    </a>
      </div>
      <div class="product-item">
      <a href="Tracker page.php"> <img src="Image/furco_pawprints.png" alt="Whiskas Ocean Fish Flavor Loaf" >
        <h3>Whiskas Ocean Fish Flavor Loaf</h3>
        <p>Classic</p>
        <span>P80</span>
      </a>
      </div>
      <div class="product-item">
    <a href="Tracker page.php"><img src="Image/furco_pawprints.png" alt="Whiskas Ocean Fish Flavor Loaf">
        <h3>Whiskas Ocean Fish Flavor Loaf</h3>
        <p>Classic</p>
        <span>P80</span>
    </a>
      </div>
      <div class="product-item">
    <a href="Tracker page.php"><img src="Image/furco_pawprints.png" alt="Whiskas Ocean Fish Flavor Loaf">
        <h3>Whiskas Ocean Fish Flavor Loaf</h3>
        <p>Classic</p>
        <span>P80</span>
    </a>
      </div>
    </section>
    <div class="view-more">
        <a href="#">View More</a>
      </div>
  </main>
  
</body>

</html>
