<?php include('Php/functions.php') ?>
<?= template_header('Home') ?>


<div class="banner"></div>


<div class="body">
    <h1>FURCO</h1>
    <p>A family owned business, looking to give pets and pet owners their wants and needs anytime!</p>
</div>


<div class="content">
    <!-- notification message -->
    <?php if (isset($_SESSION['success'])) : ?>
        <div class="error success">
            <h3>
                <?php
                echo $_SESSION['success'];
                unset($_SESSION['success']);
                ?>
            </h3>
        </div>
    <?php endif ?>
    <!-- logged in user information -->
    <div class="profile_info">
        <img src="images/user_profile.png">


<?= template_footer() ?>