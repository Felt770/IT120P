<?php 
include('Php/functions.php');

if (!isAdmin()) {
        $_SESSION['msg'] = "You must log in first";
        header('location: login.php');
}

if (isset($_GET['logout'])) {
        session_destroy();
        unset($_SESSION['user']);
        header("location: login.php");
}
?>

<?= template_header('Order History') ?>
 <link rel="stylesheet" href="Style/History style.css">
  <main>
    <h1>Order History</h1>
    <section class="order-list">
      <h2>Recent Orders</h2>
      <div class="order-item">
      </div>
      <button class="view-more">View More</button>
    </section>
  </main>
  <?= template_footer() ?>