<?php include('Php/functions.php') ?>
<?php
session_start(); 

var_dump($_SESSION['user']);
if (isset($_SESSION['user'])) {
    echo '<a href="subscriptions.php">Subscription</a>';
    echo '<a href="OrderHistoryPage.php">My Order</a>';
    echo '<button><img src="Image/furco_cart.png" alt="FURCO Cart" class="cart"></button>';
    echo '<button><img src="Image/furco_profile.png" alt="FURCO Profile" class="profile"></button>';
  } else {
    echo '<a href="Home.php">Home</a>';
    echo '<a href="Product.php">Products</a>';
    echo '<a href="login.php"><button class="sign-in">Sign In</button></a>';
  }
?>

<a href="Home.php">Home</a>
<a href="Product.php">Products</a>

