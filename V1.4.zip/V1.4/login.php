<?php
include 'Php/functions.php';  // Include your functions file
?>
<?= template_header('login') ?>

    <section class="align-items-center position-relative py-4 py-xl-5">
        <div class="container-fluid d-grid justify-content-center align-items-center">
            <div class="card d-grid mb-5" style="width: 637px;height: 417px;border-radius: 19px;background: #ffffff00;">
                <div class="card-body" style="background: #f9c180;width: 637px;height: 417px;border-radius: 19px;box-shadow: 0px 5px 10px;">
                    <div style="width: 592.2969px;border-bottom-width: 2px;border-bottom-style: solid;">
                        <h2 style="font-family: Poppins, sans-serif;">Login</h2>
                    </div>
                    <p class="w-lg-50" style="font-family: Poppins, sans-serif;">Welcome Back! Sign in to your account.</p>
                    <form class="text-center" method="post" action="Php/functions.php" >
                        <div class="mb-3"><input class="form-control-plaintext" type="text" value="Email Address *" 
                        style="font-weight: bold;font-family: Poppins, sans-serif;font-size: 14px;">
                        <input class="form-control" type="email" name="email" style="border-radius: 22px;font-family: Poppins, sans-serif;" required="">
                    </div>
                        <div class="mb-3"><input class="form-control-plaintext" type="text" value="Password *"
                        style="font-size: 14px;font-family: Poppins, sans-serif;font-weight: bold;">
                        <input class="form-control" type="password" name="password" style="border-radius: 22px;font-family: Poppins, sans-serif;" required="">
                    </div>
                        <div class="mb-3"><button name="submit" class="btn btn-primary d-block w-100" type="submit" 
                        style="background: #ff8e3c;font-family: Poppins, sans-serif;font-size: 14px;border-radius: 22px;border-color: #ffffff00;color: rgb(0,0,0);font-weight: bold;">Login</button>
                    </div>
                        <p class="text-muted" style="font-family: Poppins, sans-serif;font-size: 14px;">Don't have an account? <a href="register.php"><strong>Sign Up</strong></a></p>
                    </form>
                </div>
            </div>
        </div>
    </section>
    
    <?= template_footer() ?>