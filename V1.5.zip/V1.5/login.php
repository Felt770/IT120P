<?php include 'Php/functions.php'; ?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>login</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="Style/bootstrap.min.css">
    <link rel="stylesheet" href="Style/style.css">
</head>

<body>
    <div class="navbar">
        <img src="Image/furco_logo.png" alt="FURCO Paw Logo" class="logo">
        <h1>FURCO</h1>
        <div class="search-container">
            <img src="Image/furco_search.png" alt="Search" class="search-icon">
            <input type="search" placeholder="Search">
        </div>
        <?php require_once("Php/navigation.php"); ?>
    </div>

    <section class="align-items-center position-relative py-4 py-xl-5">
        <div class="container-fluid d-grid justify-content-center align-items-center">
            <?php if ($errors && count($errors) > 0) {
                foreach ($errors as $x) {
            ?>
                    <h1><?php $x ?> </h1>

            <?php
                }
            } ?>
            <div class="card d-grid mb-5" style="width: 637px;height: 417px;border-radius: 19px;background: #ffffff00;">
                <div class="card-body" style="background: #f9c180;width: 637px;height: 417px;border-radius: 19px;box-shadow: 0px 5px 10px;">
                    <div style="width: 592.2969px;border-bottom-width: 2px;border-bottom-style: solid;">
                        <h2 style="font-family: Poppins, sans-serif;">Login</h2>
                    </div>
                    <p class="w-lg-50" style="font-family: Poppins, sans-serif;">Welcome Back! Sign in to your account.</p>
                    <form class="text-center" method="post" action="Php/functions.php">
                        <div class="mb-3"><input class="form-control-plaintext" type="text" value="Email Address *" style="font-weight: bold;font-family: Poppins, sans-serif;font-size: 14px;">
                            <input class="form-control" type="email" name="email" style="border-radius: 22px;font-family: Poppins, sans-serif;" required="">
                        </div>
                        <div class="mb-3"><input class="form-control-plaintext" type="text" value="Password *" style="font-size: 14px;font-family: Poppins, sans-serif;font-weight: bold;">
                            <input class="form-control" type="password" name="password" style="border-radius: 22px;font-family: Poppins, sans-serif;" required="">
                        </div>
                        <div class="mb-3"><button name="submit" class="btn btn-primary d-block w-100" type="submit" style="background: #ff8e3c;font-family: Poppins, sans-serif;font-size: 14px;border-radius: 22px;border-color: #ffffff00;color: rgb(0,0,0);font-weight: bold;">Login</button>
                        </div>
                        <p class="text-muted" style="font-family: Poppins, sans-serif;font-size: 14px;">Don't have an account? <a href="register.php"><strong>Sign Up</strong></a></p>
                    </form>
                </div>
            </div>
        </div>
    </section>

    <?= template_footer() ?>