<?php include('Php/functions.php') ?>
<head>
  <meta charset="utf-8">
  <title>Home</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel="stylesheet" href="Style/History style.css">
  <link rel="stylesheet" href="Style/bootstrap.min.css">
  <link rel="stylesheet" href="Style/style.css">
</head>

<body>
  <div class="navbar">
    <img src="Image/furco_logo.png" alt="FURCO Paw Logo" class="logo">
    <h1>FURCO</h1>
    <div class="search-container">
      <img src="Image/furco_search.png" alt="Search" class="search-icon">
      <input type="search" placeholder="Search">
    </div>
    <?php require_once("Php/navigation.php"); ?>
  </div>
<section class="d-flex justify-content-center align-items-center position-relative py-4 py-xl-5">
        <div class="container d-flex justify-content-center align-items-center">
            <div class="card d-flex justify-content-center align-items-center mb-5" style="width: 637px; height: 607px; border-radius: 19px; background: #ffffff00;">
                <div class="card-body" style="background: #f9c180; width: 637px; height: 607px; border-radius: 19px; box-shadow: 0px 5px 10px;">
                    <div class="d-flex justify-content-start" style="width: 592.2969px; border-bottom-width: 2px; border-bottom-style: solid;">
                        <h2 style="font-family: Poppins, sans-serif;">Register</h2>
                    </div>
                    <p class="w-lg-50" style="font-family: Poppins, sans-serif; font-size: 13px;"><br>Create new account today to reap the benefits of a personalized shopping experience.<br><br></p>
                    <form class="text-center" method="post" action="register.php">
                        <?php
                        if ($_SERVER["REQUEST_METHOD"] == "POST") {
                            $username = $_POST['full_name'];
                            $email = $_POST['email'];
                            $password = $_POST['password'];
                            $phonenumber = $_POST['phone_number'];

                            if (register_user($username, $email, $password, $phonenumber)) {
                                $_SESSION['message'] = 'Registration successful!';
                                header('location: login.php'); // Redirect after successful registration
                                exit();
                            }
                        }
                        echo display_error();
                        ?>
                        <div class="mb-3"><input class="form-control-plaintext" type="text" value="Username*" readonly="" style="font-weight: bold; font-family: Poppins, sans-serif; font-size: 14px;"><input class="form-control" type="text" name="full_name" placeholder="" style="width: 598px; border-radius: 22px; height: 42px; font-family: Poppins, sans-serif;"></div>
                        <div class="mb-3"><input class="form-control-plaintext" type="text" value="Email*" readonly="" style="font-weight: bold; font-family: Poppins, sans-serif; font-size: 14px;"><input class="form-control" type="email" name="email" placeholder="" style="width: 598px; border-radius: 22px; height: 42px; font-family: Poppins, sans-serif;"></div>
                        <div class="mb-3"><input class="form-control-plaintext" type="text" value="Password*" readonly="" style="font-size: 14px; font-family: Poppins, sans-serif; font-weight: bold;"><input class="form-control" type="password" name="password" placeholder="" style="height: 42px; border-radius: 22px; font-family: Poppins, sans-serif;"></div>
                        <div class="mb-3"><input class="form-control-plaintext" type="text" value="Phone Number*" readonly="" style="font-size: 14px; font-family: Poppins, sans-serif; font-weight: bold;"><input class="form-control" type="text" name="phone_number" placeholder="" style="height: 42px; border-radius: 22px; font-family: Poppins, sans-serif;"></div>
                        <div class="mb-3"><button class="btn btn-primary d-block w-100" type="submit" style="height: 44px; background: #ff8e3c; font-family: Poppins, sans-serif; font-size: 14px; border-radius: 22px; border-color: #ffffff00; color: rgb(0,0,0); font-weight: bold;">Register</button></div>
                    </form>
                </div>
            </div>
        </div>
    </section>
<?= template_footer() ?>