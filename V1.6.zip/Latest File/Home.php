<?php include('Php/functions.php') ?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>Home</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="Style/bootstrap.min.css">
    <link rel="stylesheet" href="Style/style.css">
</head>

<body>
    <div class="navbar">
        <img src="Image/furco_logo.png" alt="FURCO Paw Logo" class="logo">
        <h1>FURCO</h1>
        <div class="search-container">
            <img src="Image/furco_search.png" alt="Search" class="search-icon">
            <input type="search" placeholder="Search">
        </div>
        <?php require_once("Php/navigation.php"); ?>
    </div>
    <div class="banner"></div>


    <div class="body">
        <h1>FURCO</h1>
        <p>A family owned business, looking to give pets and pet owners their wants and needs anytime!</p>
    </div>


    <?= template_footer() ?>