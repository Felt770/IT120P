<?php

if (isset($_SESSION['user'])) {
  echo '<a href="Home.php">Home</a>';
  echo '<a href="Products.php">Products</a>';
  echo '<a href="subscriptions.php">Subscription</a>';
  echo '<a href="OrderHistoryPage.php">My Orders</a>';
  echo '<div class="dropdown">
          <button class="dropbtn"><img src="Image/furco_profile.png" alt="Profile" class="profile"></button>
          <div class="dropdown-content">
              <a href="User Profile.php">User Profile</a>
              <a href="Home.php?logout=1">Logout</a>
          </div>
        </div>';
} else {

  echo '<a href="Home.php">Home</a>';
  echo '<a href="Products.php">Products</a>';
  echo '<div class="sign-in"><a href="login.php">Sign In</a></div>';
}
?>