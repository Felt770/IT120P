<?php 
include('Php/functions.php');

if (!isAdmin()) {
        $_SESSION['msg'] = "You must log in first";
        header('location: login.php');
}

if (isset($_GET['logout'])) {
        session_destroy();
        unset($_SESSION['user']);
        header("location: login.php");
}
?>
<?php 
    $subscriptions = [
        ['id' => 1,
            'name' => 'Whiskas', 
            'description' => 'Ocean Fish Flavor Loaf', 
            'price' => 80, 
            'image' => 'Image/whiskas.png',
            'arrival' => 'Monday, May 20', 
            'address-line-1' => '101 Emerald St. Brgy Dolores,',
            'address-line-2' => 'San Fernando, Pampanga'],
        ['id' => 2,
            'name' => 'Vitality', 
            'description' => 'Classic', 
            'price' => 100, 
            'image' => 'Image/vitality-1.png',
            'arrival' => 'Monday, May 20', 
            'address-line-1' => '101 Emerald St. Brgy Dolores,',
            'address-line-2' => 'San Fernando, Pampanga'],
        ['id' => 3,
            'name' => 'Pedigree', 
            'description' => 'Adult', 
            'price' => 120, 
            'image' => 'Image/pedigree.png',
            'arrival' => 'Monday, May 20', 
            'address-line-1' => '101 Emerald St. Brgy Dolores,',
            'address-line-2' => 'San Fernando, Pampanga'],
        ['id' => 4,
            'name' => 'Vitality', 
            'description' => 'High Energy', 
            'price' => 130, 
            'image' => 'Image/vitality-2.png',
            'arrival' => 'Monday, May 20', 
            'address-line-1' => '101 Emerald St. Brgy Dolores,',
            'address-line-2' => 'San Fernando, Pampanga'],
        ['id' => 5,
            'name' => 'Whiskas', 
            'description' => 'Ocean Fish Flavor Loaf', 
            'price' => 80, 
            'image' => 'Image/whiskas.png',
            'arrival' => 'Monday, May 20', 
            'address-line-1' => '101 Emerald St. Brgy Dolores,',
            'address-line-2' => 'San Fernando, Pampanga'],
        ['id' => 6,
            'name' => 'Vitality', 
            'description' => 'Classic', 
            'price' => 100, 
            'image' => 'Image/vitality-1.png',
            'arrival' => 'Monday, May 20', 
            'address-line-1' => '101 Emerald St. Brgy Dolores,',
            'address-line-2' => 'San Fernando, Pampanga'],
        ['id' => 7,
            'name' => 'Pedigree', 
            'description' => 'Adult', 
            'price' => 120, 
            'image' => 'Image/pedigree.png',
            'arrival' => 'Monday, May 20', 
            'address-line-1' => '101 Emerald St. Brgy Dolores,',
            'address-line-2' => 'San Fernando, Pampanga'],
        ['id' => 8,
            'name' => 'Vitality', 
            'description' => 'High Energy', 
            'price' => 130, 
            'image' => 'Image/vitality-2.png',
            'arrival' => 'Monday, May 20', 
            'address-line-1' => '101 Emerald St. Brgy Dolores,',
            'address-line-2' => 'San Fernando, Pampanga']
    ]; 
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="Style/subscriptions.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <title>Your Subscriptions</title>
    <link rel="icon" type="image/x-icon" href="Image/furco_logo.png">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
</head>
<body>
<div class="navbar">
        <img src="Image/furco_logo.png" alt="FURCO Paw Logo" class="logo">
        <h1>FURCO</h1>
        <div class="search-container">
            <img src="Image/furco_search.png" alt="Search" class="search-icon">
            <input type="search" placeholder="Search">
        </div>
        <?php require_once("Php/navigation.php"); ?>
    </div>
  
    <main>
        <h1>Subscriptions</h1>


        <section class="subscription-list">
            <?php foreach ($subscriptions as $subscription): ?>
                <a href = "subscription-view.php?id=<?php echo $subscription['id']; ?>">
                    <div class="subcription-item">
                        <img src="<?php echo $subscription['image']; ?>" alt="<?php echo $subscription['name']; ?>">
                        
                        <div class="subcription-desc">
                            <h3><?php echo $subscription['name']; ?></h3>
                            <p><?php echo $subscription['description']; ?></p>
                            <span class="price">₱<?php echo $subscription['price']; ?> </span>
                        </div>
                    </div>
                </a>
            <?php endforeach; ?>
        </section>
    </main>
    <?= template_footer() ?>
   
